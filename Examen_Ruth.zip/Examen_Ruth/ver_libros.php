<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "biblioteca";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar la variable de búsqueda
$search_id = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $search_id = $_POST['search_id'];
}

// Construir la consulta SQL
$sql = "SELECT libros.ID_Libro, libros.titulo, libros.fecha_publicacion, autor.nombre, autor.apellido, libros.precio
        FROM libros
        INNER JOIN autor ON libros.autor_id = autor.ID_Autor";

if (!empty($search_id)) {
    $sql .= " WHERE libros.ID_Libro = $search_id";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar Libros</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-800 p-6">
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-4xl mx-auto">
        <h2 class="text-2xl font-bold mb-6 text-gray-800">Lista de Libros</h2>
        
        <!-- Formulario de búsqueda -->
        <form action="ver_libros.php" method="post" class="mb-6">
            <div class="flex items-center">
                <input type="number" name="search_id" placeholder="Buscar por ID" value="<?php echo htmlspecialchars($search_id); ?>" class="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                <button type="submit" class="ml-2 py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Buscar</button>
            </div>
        </form>

        <table class="min-w-full bg-white border border-gray-200">
            <thead>
                <tr>
                    <th class="py-2 px-4 border-b">ID</th>
                    <th class="py-2 px-4 border-b">Título</th>
                    <th class="py-2 px-4 border-b">Fecha de Publicación</th>
                    <th class="py-2 px-4 border-b">Autor</th>
                    <th class="py-2 px-4 border-b">Precio</th>
                    <th class="py-2 px-4 border-b">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Salida de datos de cada fila
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["ID_Libro"]. "</td>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["titulo"]. "</td>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["fecha_publicacion"]. "</td>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["nombre"] . " " . $row["apellido"] . "</td>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["precio"]. "</td>";
                        echo "<td class='py-2 px-4 border-b'>";
                        echo "<a href='editar_libro.php?id=" . $row["ID_Libro"] . "' class='text-blue-500 hover:underline mr-2'>Editar</a>";
                        echo "<a href='eliminar_libro.php?id=" . $row["ID_Libro"] . "' class='text-blue-500 hover:underline'>Eliminar</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='py-2 px-4 border-b text-center'>No se encontraron libros</td></tr>";
                }

                // Cerrar conexión
                $conn->close();
                ?>
            </tbody>
        </table>
        <div class="mt-6">
            <a href="index.php" class="text-blue-500 hover:underline">Volver a la página principal</a>
        </div>
    </div>
</body>
</html>
