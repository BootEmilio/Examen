<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "biblioteca";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titulo = $_POST['titulo'];
    $fecha_publicacion = $_POST['fecha_publicacion'];
    $autor_id = $_POST['autor_id'];
    $precio = $_POST['precio'];

    // Preparar la consulta SQL
    $sql = "INSERT INTO libros (titulo, fecha_publicacion, autor_id, precio)
            VALUES ('$titulo', '$fecha_publicacion', $autor_id, $precio)";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Nuevo libro añadido exitosamente'); window.location.href='index.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Cerrar conexión
$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Libro</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-800 p-6">
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md mx-auto">
        <h2 class="text-2xl font-bold mb-6 text-gray-800">Agregar Libro</h2>
        <form action="agregar_libro.php" method="post" class="space-y-4">
            <div>
                <label for="titulo" class="block text-sm font-medium text-gray-700">Título:</label>
                <input type="text" name="titulo" id="titulo" required class="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
            </div>
            <div>
                <label for="fecha_publicacion" class="block text-sm font-medium text-gray-700">Fecha de Publicación:</label>
                <input type="date" name="fecha_publicacion" id="fecha_publicacion" required class="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
            </div>
            <div>
                <label for="autor_id" class="block text-sm font-medium text-gray-700">Autor ID:</label>
                <input type="number" name="autor_id" id="autor_id" required class="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
            </div>
            <div>
                <label for="precio" class="block text-sm font-medium text-gray-700">Precio:</label>
                <input type="number" step="0.01" name="precio" id="precio" required class="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
            </div>
            <div>
                <input type="submit" value="Agregar Libro" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
            </div>
        </form>
    </div>
</body>
</html>
