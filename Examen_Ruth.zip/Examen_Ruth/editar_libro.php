<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "biblioteca";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables para almacenar datos del libro
$idLibro = "";
$titulo = "";
$fechaPublicacion = "";
$autorId = "";
$precio = "";

// Verificar si se proporcionó el parámetro ID en la URL
if (isset($_GET['id'])) {
    $idLibro = $_GET['id'];

    // Consulta SQL para obtener los datos del libro específico
    $sql = "SELECT ID_Libro, titulo, fecha_publicacion, autor_id, precio FROM libros WHERE ID_Libro = $idLibro";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Obtener los datos del libro
        $row = $result->fetch_assoc();
        $titulo = $row['titulo'];
        $fechaPublicacion = $row['fecha_publicacion'];
        $autorId = $row['autor_id'];
        $precio = $row['precio'];
    } else {
        echo "No se encontró ningún libro con ID: $idLibro";
        exit();
    }
}

// Procesamiento del formulario cuando se envía
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir los datos del formulario
    $idLibro = $_POST['idLibro'];
    $titulo = $_POST['titulo'];
    $fechaPublicacion = $_POST['fecha_publicacion'];
    $autorId = $_POST['autor_id'];
    $precio = $_POST['precio'];

    // Actualizar los datos del libro en la base de datos
    $sqlUpdate = "UPDATE libros SET titulo = '$titulo', fecha_publicacion = '$fechaPublicacion', autor_id = '$autorId', precio = '$precio' WHERE ID_Libro = $idLibro";

    if ($conn->query($sqlUpdate) === TRUE) {
        echo "<script>alert('libro editado exitosamente'); window.location.href='ver_libros.php.php';</script>";
    } else {
        echo "Error al actualizar los datos del libro: " . $conn->error;
    }
}

// Cerrar conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Libro</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 p-6">
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md mx-auto">
        <h2 class="text-2xl font-bold mb-6 text-gray-800">Editar Libro</h2>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="hidden" name="idLibro" value="<?php echo $idLibro; ?>">
            <div class="mb-4">
                <label for="titulo" class="block text-gray-800 font-bold mb-2">Título:</label>
                <input type="text" id="titulo" name="titulo" value="<?php echo $titulo; ?>" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mb-4">
                <label for="fecha_publicacion" class="block text-gray-800 font-bold mb-2">Fecha de Publicación:</label>
                <input type="date" id="fecha_publicacion" name="fecha_publicacion" value="<?php echo $fechaPublicacion; ?>" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mb-4">
                <label for="autor_id" class="block text-gray-800 font-bold mb-2">Autor ID:</label>
                <input type="number" id="autor_id" name="autor_id" value="<?php echo $autorId; ?>" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mb-4">
                <label for="precio" class="block text-gray-800 font-bold mb-2">Precio:</label>
                <input type="number" step="0.01" id="precio" name="precio" value="<?php echo $precio; ?>" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mt-6">
                <button type="submit" class="bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700">Guardar Cambios</button>
                <a href="ver_libros.php" class="ml-4 text-gray-600 hover:text-gray-800">Cancelar o atras</a>
            </div>
        </form>
    </div>
</body>
</html>
