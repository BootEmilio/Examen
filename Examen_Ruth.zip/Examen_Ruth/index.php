<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteca Don Emilio</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-800 flex items-center justify-center h-screen space-x-8">
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h2 class="text-2xl font-bold mb-6 text-gray-800">Administración de Autores</h2>
        <div class="space-y-4">
            <a href="ver_autores.php" class="block text-center bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700">
                Ver Todos los autores
            </a>
            <a href="agregar_autor.php" class="block text-center bg-green-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-700">
                Añadir Nuevo autor
            </a>
            </a>
        </div>
    </div>
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h2 class="text-2xl font-bold mb-6 text-gray-800">Administración de Libros</h2>
        <div class="space-y-4">
            <a href="ver_libros.php" class="block text-center bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700">
                Ver Todos los libros
            </a>
            <a href="agregar_libro.php" class="block text-center bg-green-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-700">
                Añadir Nuevo libro
            </a>
            </a>
        </div>
    </div>
</body>
</html>
