<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "biblioteca";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables para almacenar datos del autor
$idAutor = "";
$nombre = "";
$apellido = "";
$fechaNacimiento = "";

// Verificar si se proporcionó el parámetro ID en la URL
if (isset($_GET['id'])) {
    $idAutor = $_GET['id'];

    // Consulta SQL para obtener los datos del autor específico
    $sql = "SELECT ID_Autor, nombre, apellido, fecha_nacimiento FROM Autor WHERE ID_Autor = $idAutor";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Obtener los datos del autor
        $row = $result->fetch_assoc();
        $nombre = $row['nombre'];
        $apellido = $row['apellido'];
        $fechaNacimiento = $row['fecha_nacimiento'];
    } else {
        echo "No se encontró ningún autor con ID: $idAutor";
        exit();
    }
}

// Procesamiento del formulario cuando se envía
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir los datos del formulario
    $idAutor = $_POST['idAutor'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $fechaNacimiento = $_POST['fecha_nacimiento'];

    // Actualizar los datos del autor en la base de datos
    $sqlUpdate = "UPDATE Autor SET nombre = '$nombre', apellido = '$apellido', fecha_nacimiento = '$fechaNacimiento' WHERE ID_Autor = $idAutor";

    if ($conn->query($sqlUpdate) === TRUE) {
        echo "Los datos del autor han sido actualizados correctamente.";
    } else {
        echo "Error al actualizar los datos del autor: " . $conn->error;
    }
}

// Cerrar conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Autor</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-800 p-6">
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md mx-auto">
        <h2 class="text-2xl font-bold mb-6 text-gray-800">Editar Autor</h2>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="hidden" name="idAutor" value="<?php echo $idAutor; ?>">
            <div class="mb-4">
                <label for="nombre" class="block text-gray-800 font-bold mb-2">Nombre:</label>
                <input type="text" id="nombre" name="nombre" value="<?php echo $nombre; ?>" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mb-4">
                <label for="apellido" class="block text-gray-800 font-bold mb-2">Apellido:</label>
                <input type="text" id="apellido" name="apellido" value="<?php echo $apellido; ?>" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mb-4">
                <label for="fecha_nacimiento" class="block text-gray-800 font-bold mb-2">Fecha de Nacimiento:</label>
                <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" value="<?php echo $fechaNacimiento; ?>" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mt-6">
                <button type="submit" class="bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700">Guardar Cambios</button>
                <a href="ver_autores.php" class="ml-4 text-gray-600 hover:text-gray-800">Cancelar o atras</a>
            </div>
        </form>
    </div>
</body>
</html>
